from pathlib import Path
import re,subprocess,json
r=Path(__file__).resolve().parent;b=r.parent
sym='?js_new_cc_CanvasRenderingContext2D@@YA_NAEAVState@se@@@Z'
rows={}
for key,folder in [('incremental',b/'gpu-win-trace-lifecycle'),('clean',r/'clean-trace-build'),('formal',b/'m6-remaining-554d747561/trace-build-Debug')]:
    p=folder/'CMakeFiles/cocos_engine.dir/generated/cocos/bindings/auto/jsb_cocos_auto.cpp.obj'
    buf=subprocess.check_output(['objdump','-d','-Mintel','--disassemble='+sym,str(p)]).decode(errors='replace')
    mark='<'+sym+'>:'
    part=buf.split(mark)[1].split('\n\n')[0]
    rows[key]=re.findall(r'mov\s+ecx,0x([0-9a-f]+)',part)
    (r/('canvas-ctor-'+key+'.txt')).write_text(part)
print(rows)
(r/'canvas-abi.json').write_text(json.dumps(rows,indent=2))

