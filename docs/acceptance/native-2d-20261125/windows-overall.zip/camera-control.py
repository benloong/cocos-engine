from pathlib import Path
import json,subprocess,shutil,time,hashlib
r=Path(__file__).resolve().parent
ref=r/'behavior-final-Release'; member='active window screen center and outside'
src='native/tests/2d-poc/fixtures/acceptance/m6-behavior/public.js'
old=subprocess.check_output(['git','show','c9a19863e3:'+src])
rows=[]
for tag in ['old','fixed']:
    d=r/('camera-control-'+tag);d.mkdir();(d/'writable').mkdir()
    for f in [*ref.glob('*.dll'),ref/'cocos-m1-test.exe']:shutil.copy2(f,d/f.name)
    shutil.copytree(ref/'Resources',d/'Resources')
    main=d/'Resources/main.js';s=main.read_bytes();assert ref.as_posix().encode() in s;main.write_bytes(s.replace(ref.as_posix().encode(),d.as_posix().encode()))
    public=d/'Resources/m6-behavior/public.js'
    if tag=='old':public.write_bytes(old)
    else:assert public.read_bytes()==Path(src).read_bytes()
    harness=d/'Resources/m6-behavior/run.js';s=harness.read_text();needle='        for (const { owner, members, name, run } of tests) {'
    addition="""        const hit = tests.findIndex(t => t.name === 'active window screen center and outside');
        if (hit < 0) throw Error('missing screen behavior');
        tests.unshift(tests.splice(hit, 1)[0]);
        const c = cc.director.getScene().getComponentInChildren(cc.Canvas);
        const component = c.cameraComponent;
        for (let i=0; i<180 && !component.targetTexture; ++i) await frame();
        const offscreen = !!component.targetTexture && !!component.camera.window && !component.camera.window.swapchain;
        const pos = component.camera.worldToScreen(new cc.Vec3(), c.node.worldPosition);
        const hitNow = c.getComponent(cc.UITransform).hitTest(new cc.Vec2(pos.x,pos.y), component.camera.systemWindowId);
        console.log('M6_CAMERA_CONTROL ' + JSON.stringify({offscreen, hitNow, window:component.camera.systemWindowId}));
"""
    assert s.count(needle)==1;harness.write_text(s.replace(needle,addition+needle))
    with (d/'stdout.log').open('wb') as log,(d/'stderr.log').open('wb') as err:
        proc=subprocess.run([str(d/'cocos-m1-test.exe')],cwd=d,stdout=log,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW,timeout=120)
    assert proc.returncode==0
    report=json.loads((d/'checks.json').read_text()); assert report['complete'] and len(report['cases'])==82
    failed=[a['name'] for a in report['cases'] if not a['passed']]
    marker=[line.split('M6_CAMERA_CONTROL ')[-1] for line in (d/'stdout.log').read_text(errors='replace').splitlines() if 'M6_CAMERA_CONTROL ' in line]
    assert len(marker)==1
    observed=json.loads(marker[0])
    assert observed['offscreen'] and not observed['hitNow'] and observed['window']>0
    assert failed==([member] if tag=='old' else []),(tag,failed)
    rows.append(dict(fixture=tag,applicationSha256=hashlib.sha256((d/'cocos-m1-test.exe').read_bytes()).hexdigest(),beforeCase=observed,failedCases=failed,total=len(report['cases'])))
    print(tag,observed,failed,flush=True)
(r/'camera-control.json').write_text(json.dumps(rows,indent=2))

