const fs=require('node:fs'), path=require('node:path'), os=require('node:os'), assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');
const root=process.cwd(), r=__dirname, proj=path.resolve('../cocos-m1-test');
const {WindowsPackTool}=require(path.join(root,'scripts/native-pack-tool/dist/platforms/windows'));
const {cocosConfig}=require(path.join(root,'scripts/native-pack-tool/dist/cocosConfig'));
const rows=[];
const t=fs.mkdtempSync(path.join(proj,'build/v26-'));
function init(project,dir,version,projectName='generator-check'){
  const tool=new WindowsPackTool();
  tool.init({projDir:project,buildDir:dir,enginePath:root,nativeEnginePath:path.join(root,'native'),platform:'windows',projectName,cmakePath:process.argv[2],platformParams:{vsVersion:version,targetPlatform:'x64'},debug:true});
  return tool;
}
function verify(dir){
  const cache=fs.readFileSync(path.join(dir,'proj/CMakeCache.txt'),'utf8');
  const values=Object.fromEntries(['CMAKE_GENERATOR','CMAKE_GENERATOR_PLATFORM','CMAKE_GENERATOR_INSTANCE'].map(k=>[k,cache.match(new RegExp('^'+k+':INTERNAL=(.*)$','m'))[1]]));
  assert.equal(values.CMAKE_GENERATOR,'Visual Studio 18 2026');assert(fs.existsSync(values.CMAKE_GENERATOR_INSTANCE));
  const vcx=fs.readdirSync(path.join(dir,'proj')).find(p=>p==='generator-check.vcxproj'||p==='cocos-m1-test.vcxproj');
  assert(vcx);
  const project=fs.readFileSync(path.join(dir,'proj',vcx),'utf8');
  for(const cfg of ['Debug','Release'])assert(project.includes('Include="'+cfg+'|x64"'));
  values.solutionPlatform='x64';
  return values;
}
(async()=>{
  const table=cocosConfig.cmake.windows.generators; assert.equal(table[0].G,'Visual Studio 18 2026');assert(table.every(g=>!g.G.includes('Ninja')));
  const src=path.join(t,'small project');const win=path.join(src,'native/engine/win64');fs.mkdirSync(win,{recursive:true});
  fs.writeFileSync(path.join(win,'CMakeLists.txt'),'cmake_minimum_required(VERSION 3.16)\nproject(generator-check LANGUAGES CXX)\nadd_executable(generator-check main.cpp)\n');
  fs.writeFileSync(path.join(win,'main.cpp'),'int main(){return 0;}\n');
  process.env.CC_USE_NINJA='1';process.env.CMAKE_GENERATOR='Ninja';
  assert.equal(init(src,path.join(t,'version-check'),'2022').getCmakeGenerator(),'2022');
  for(const [mode,year] of [['automatic',''],['explicit','2026']]){
    const dir=path.join(t,mode);const tool=init(src,dir,year);
    assert.equal(tool.getCmakeGenerator(),year);
    await tool.generate();await tool.generate();
    const info=verify(dir);
    for(const cfg of ['Debug','Release']){tool.params.debug=cfg==='Debug';await tool.make();execFileSync(path.join(dir,'proj',cfg,'generator-check.exe'));}
    rows.push({mode,...info,configurations:['Debug','Release']});
  }
  const dir=path.join(t,'game');fs.mkdirSync(path.join(dir,'proj'),{recursive:true});
  fs.copyFileSync(path.join(proj,'build/windows/proj/cfg.cmake'),path.join(dir,'proj/cfg.cmake'));
  fs.cpSync(path.join(proj,'build/windows/data'),path.join(dir,'data'),{recursive:true});
  const tool=init(proj,dir,'2026','cocos-m1-test');await tool.generate();
  rows.push({mode:'cocos-m1-test',...verify(dir),dir});
  fs.writeFileSync(path.join(r,'vs-configured.json'),JSON.stringify({rows},null,2));
  for(const cfg of ['Debug','Release']){
    execFileSync(process.argv[2],['--build',path.join(dir,'proj'),'--config',cfg,'--target','cocos-m1-test','--parallel','8'],{stdio:'inherit'});
    const exe=path.join(dir,'proj',cfg,'cocos-m1-test.exe'); assert(fs.statSync(exe).size>0);
    (rows[2].artifacts??={})[cfg]=require('node:crypto').createHash('sha256').update(fs.readFileSync(exe)).digest('hex');
  }
  fs.writeFileSync(path.join(r,'vs-generator.json'),JSON.stringify({rows},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});

