from pathlib import Path
import re,json,subprocess
r=Path(__file__).resolve().parent;b=r.parent
rows={}
for key,folder,size in [('incremental',b/'gpu-win-trace-lifecycle',424),('clean',r/'clean-trace-build',432),('formal',b/'m6-remaining-554d747561/trace-build-Debug',432)]:
    obj=folder/'CMakeFiles/cocos_engine.dir/generated/cocos/bindings/auto/jsb_cocos_auto.cpp.obj'
    part=(r/f'canvas-ctor-{key}.txt').read_text()
    call=re.search(r'mov\s+ecx,0x'+format(size,'x')+r'\s+([0-9a-f]+):\s+e8 ',part)
    assert call
    offset=format(int(call[1],16)+1,'016x')
    reloc=subprocess.check_output(['objdump','-r',str(obj)]).decode(errors='replace')
    line,=[x for x in reloc.splitlines() if x.startswith(offset+' ') and '??2@YAPEAX_K@Z' in x]
    rows[key]=dict(allocationBytes=size,newRelocation=line,object=str(obj.relative_to(b)))
(r/'canvas-allocation.json').write_text(json.dumps(rows,indent=2))
print(rows)

