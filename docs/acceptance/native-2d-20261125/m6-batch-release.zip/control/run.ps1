param([string[]]$Sides=@('before','after'),[int]$Rounds=3)
$ErrorActionPreference='Stop'
foreach($round in 1..$Rounds) {
 $order=@($Sides); if(!($round%2)){[array]::Reverse($order)}
 foreach($side in $order) {
  $bin=Join-Path $PSScriptRoot $side
  $log=Join-Path $PSScriptRoot "$side-$round.log"
  $p=Start-Process (Join-Path $bin 'native-2d-m6-gpu.exe') -WorkingDirectory $bin -WindowStyle Hidden -PassThru -RedirectStandardOutput $log -RedirectStandardError "$log.err"
  if(!$p.WaitForExit(180000)){ $p.Kill();throw "Timeout $log" }
  if($p.ExitCode -or !(Select-String $log -Pattern M6_PERF_DONE -Quiet)){Get-Content $log -Tail 8;throw "Failed $log"}
  Copy-Item (Join-Path $bin out.json) (Join-Path $PSScriptRoot "$side-$round.json")
  Write-Output "$side round $round complete"
 }
}
