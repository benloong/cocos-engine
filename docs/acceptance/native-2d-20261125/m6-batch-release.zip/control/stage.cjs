const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const r=__dirname,b=path.dirname(r),test=path.dirname(b),scene=path.join(b,'perf-project-before/build/windows/data');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const orig=fs.readFileSync(path.join(test,'m6-perf-workloads.js'),'utf8');
const from='for (const [name, count] of Object.entries(counts)) {';
assert.equal(orig.split(from).length,2);
const workload=orig.replace(from,from+"\n            if (name !== 'mixed') continue;").replace('stages.push([setterMs','ttfStages.push([director.root.device.numDrawCalls,director.root.device.numTris]);\n                    stages.push([setterMs').replace("console.log('M6_PERF_DONE');","console.log('M6_PERF_DONE'); cc.game.end();");
const provenance={sourceWorkload:sha(orig),controlWorkload:sha(workload),binaries:{},engines:{}};
for(const [side,rev] of [['old','f9df28d4c8'],['new','36af6fdcf6']]){
 const bin=path.join(b,'perf-bin-full-'+rev),out=path.join(r,side),res=path.join(out,'Resources');fs.mkdirSync(out,{recursive:true});
 for(const f of fs.readdirSync(bin).filter(f=>/\.(exe|dll)$/i.test(f)))fs.copyFileSync(path.join(bin,f),path.join(out,f));
 fs.cpSync(scene,res,{recursive:true});fs.cpSync(path.join(bin,'Resources/src/cocos-js'),path.join(res,'src/cocos-js'),{recursive:true});
 const entry=fs.readFileSync(path.join(scene,'main.js'),'utf8'),hook='return application.init(cc);';
 fs.writeFileSync(path.join(res,'main.js'),entry.replace(hook,()=>workload+'\ninstallM6Perf(cc,'+JSON.stringify(path.join(out,'out.json').replaceAll('\\','/'))+');'+hook));
 provenance.binaries[side]=sha(fs.readFileSync(path.join(out,'native-2d-m6-gpu.exe')));provenance.engines[side]=sha(fs.readFileSync(path.join(res,'src/cocos-js/cc.js')));
}
assert.equal(provenance.engines.old,provenance.engines.new);fs.writeFileSync(path.join(r,'control-builds.json'),JSON.stringify(provenance,null,2));
