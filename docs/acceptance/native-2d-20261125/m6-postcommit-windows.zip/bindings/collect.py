from pathlib import Path
import hashlib, json, subprocess

root = Path.cwd()
d = Path(__file__).resolve().parent
source = root
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

swig = source / 'native/external/win64/bin/swig/bin/swig.exe'
candidate = subprocess.check_output(['git','rev-parse','05197fa63c'], cwd=source, text=True).strip()
assert candidate.startswith('05197fa63c')
subprocess.run(['git','diff','--quiet',candidate,'--','native/cocos','native/tools/swig-config','cocos','tests/scripts/native-2d-decorators.test.cjs'],cwd=source,check=True)
matches = []
for build in ('out','out-release2'):
    out = d / build
    out.mkdir(exist_ok=True)
    inputs = root / 'native/tests/2d-poc/native' / build
    rules = (inputs / 'build.ninja').read_text(encoding='utf-8').splitlines()
    for module in ('2d','assets','scene'):
        config = f'/swig-config/{module}.i'
        line, = [r for r in rules if 'swig.exe -c++' in r and config in r]
        args = line.split('swig.exe ',1)[1].split(' && ',1)[0].split()
        args = [arg.replace(root.as_posix(), source.as_posix()) for arg in args]
        cpp = f'jsb_{module}_auto.cpp'
        args[args.index('-o')+1] = str(out/cpp)
        with (out / f'{module}.log').open('wb') as log:
            subprocess.run([str(swig),*args],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
        for name in (cpp, cpp.replace('.cpp','.h')):
            digest = sha(out / name)
            assert digest == sha(inputs / 'generated/cocos/bindings/auto' / name)
            matches.append(dict(build=build,file=name,sha256=digest))
meta = d / 'metadata.log'
with meta.open('wb') as log:
    subprocess.run(['node','--test','tests/scripts/native-2d-decorators.test.cjs'],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
lines = meta.read_text(encoding='utf-8')
assert 'pass 4' in lines and 'fail 0' in lines
result=dict(candidate=candidate,scope='Regenerated 2d, assets and scene bindings from verified candidate binding inputs using each native build configuration SWIG arguments. Compared both emitted files with the inputs used in the candidate core build.',artifacts=d.relative_to(root).as_posix(),swigSha256=sha(swig),metadataTestsPassed=4,metadataTestLogSha256=sha(meta),matches=matches)
(d / 'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(f'{len(matches)} binding files matched; 4 metadata tests passed')
