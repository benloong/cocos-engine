from pathlib import Path
import hashlib,json,subprocess,shutil,sys
root=Path.cwd()
out=Path(__file__).resolve().parent
build=root/'native/tests/2d-poc/build'
cfgs=('Debug','Release')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes().decode('utf-8-sig'))
def run(p,args,log,timeout):
    startup=subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow=subprocess.SW_HIDE
    with log.open('wb') as f:
        subprocess.run([str(p),*args],cwd=p.parent,stdout=f,stderr=subprocess.STDOUT,startupinfo=startup,timeout=timeout,check=True)
def copybin(src,dest,name):
    for dll in src.glob('*.dll'):shutil.copy2(dll,dest)
    shutil.copy2(src/name,dest/name)
kind=sys.argv[1]
rows=[]
for cfg in cfgs:
    src=(build/'m6-offline-exit-8ee11b673e'/cfg if kind=='rich' else build/'m6-jsb-trace-8ee11b673e/formal'/cfg)
    dest=out/(kind+'-'+cfg)
    dest.mkdir()
    (dest/'captures').mkdir()
    (dest/'writable').mkdir()
    name=('offline.exe' if cfg=='Debug' else 'cocos-m1-test.exe') if kind=='rich' else 'native-2d-m6-gpu.exe'
    copybin(src,dest,name)
    shutil.copytree(src/'Resources',dest/'Resources')
    for p in [dest/'Resources/main.js', dest/'Resources/assets/main/index.js']:
        s=p.read_bytes().replace(src.as_posix().encode(),dest.as_posix().encode())
        if kind=='trace':
            s=s.replace((build/'m6-full-source-529cb53636/native/tests/2d-poc/build/graphics-gpu-native').as_posix().encode(),(dest/'captures').as_posix().encode())
        p.write_bytes(s)
    cc=dest/'Resources/src/cocos-js/cc.js'
    shutil.copy2(out/'engine/cc.js',cc)
    expected=read(out/'engine/candidate-engine.json')['chunks']['cc.js']
    assert sha(cc)==expected
    if kind=='trace':
        log=dest/'trace.log'
        run(dest/name,[],log,240)
        assert b'M6_TRACE_DONE' in log.read_bytes() and b'Debugger listening' not in log.read_bytes()
        report=dest/'trace.json'
        subprocess.run(['node','native/tests/2d-poc/summarize-jsb-trace.cjs',str(log),str(report)],check=True)
        rows.append(dict(config=cfg,exit=0,exe=sha(dest/name),engine=sha(cc),report=sha(report)))
    else:
        ref=src/'captures-1'
        for n in range(1,4):
            log=dest/f'run-{n}.log'
            run(dest/name,[],log,160)
            assert b'M6_GPU_DONE' in log.read_bytes() and b'Debugger listening' not in log.read_bytes()
            cap=dest/'captures'
            a=read(cap/'manifest.json'); b=read(ref/'manifest.json')
            assert a==b and len(a['captures'])==58
            for f in a['captures']:assert sha(cap/(f+'.rgba'))==sha(ref/(f+'.rgba'))
            rows.append(dict(config=cfg,round=n,exit=0,images=58,exe=sha(dest/name),engine=sha(cc),manifest=sha(cap/'manifest.json')))
            cap.rename(dest/f'captures-{n}')
            cap.mkdir()
    (out/(kind+'-results.json')).write_text(json.dumps(rows,indent=2))
